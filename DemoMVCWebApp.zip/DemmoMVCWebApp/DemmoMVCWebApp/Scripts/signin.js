﻿$(document).ready(function () {

    //Global Variable Declaration.

    var $PasswordRegEx = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])[0-9a-zA-Z]{8,12}$/;
    var $EmailIdRegEx = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{2,10})(\]?)$/;
    
    var TxtEmailIdFlag = false, TxtPasswordFlag = false;

    var specialKeys = new Array();
    specialKeys.push(8); //Backspace.
    specialKeys.push(9); //Tab.
    specialKeys.push(46); //Delete.

    specialKeys.push(16); //Shift.
    specialKeys.push(20); //Caps Lock.

    specialKeys.push(37); //Right Arrow.
    specialKeys.push(39); //Left Arrow.




    //Sign In.

    
    $("#TxtEmailId").bind("blur", function (e) {
        $("#TxtEmailIdValidate").empty();
        if ($("#TxtEmailId").val() == "") {
            $("#TxtEmailIdValidate").empty();
            TxtEmailIdFlag = false;
            $("#TxtEmailIdValidate").html('(*) Email Id Required..!!');
        }
        else {
            if (!$("#TxtEmailId").val().match($EmailIdRegEx)) {
                TxtEmailIdFlag = false;
                $("#TxtEmailIdValidate").html('Invalid Email Id..!!');
            }
            else {
                $("#TxtEmailIdValidate").empty();
                TxtEmailIdFlag = true;
            }
        }
        return TxtEmailIdFlag;
    });

    $("#TxtPassword").bind("blur", function (e) {
        $("#TxtPasswordValidate").empty();
        if ($("#TxtPassword").val() == "") {
            $("#TxtPasswordValidate").html("(*) Password Required..!!");
            TxtPasswordFlag = false;
        }
        else {
            if (!$("#TxtPassword").val().match($PasswordRegEx)) {
                TxtPasswordFlag = false;
                $("#TxtPasswordValidate").html('-- Invalid Password..!!<br/><ul style="padding:20px;"><li> Minimum 8 Maximum 12 Character Required.</li><li> Atleast One Uppercase Required.</li><li> Atleast One Lowercase Required.</li><li> Atleast One Numeric Required.</li><li> NO SPECIAL CHARACTERS ALLOWED.</li></ul>');
            }
            else {
                $("#TxtPasswordValidate").empty();
                TxtPasswordFlag = true;
            }
        }
        return TxtPasswordFlag;
    });

    $("#BtnSignIn").click(function () {
        
        if ($("#TxtEmailId").val() == "") {
            $("#TxtEmailIdValidate").empty();
            $("#TxtEmailIdValidate").html('(*) Email Id Required..!!');
        }
        else {
            $("#TxtEmailIdValidate").empty();
            if (!$("#TxtEmailId").val().match($EmailIdRegEx)) {
                TxtEmailIdFlag = false;
                $("#TxtEmailIdValidate").html('Invalid Email Id..!!');
            }
            else {
                $("#TxtEmailIdValidate").empty();
                TxtEmailIdFlag = true;
            }
        }

        $("#TxtPasswordValidate").empty();
        if ($("#TxtPassword").val() == "") {
            $("#TxtPasswordValidate").html("(*) Password Required..!!");
            TxtPasswordFlag = false;
        }
        else {
            if (!$("#TxtPassword").val().match($PasswordRegEx)) {
                TxtPasswordFlag = false;
                $("#TxtPasswordValidate").html('-- Invalid Password..!!<br/><ul style="padding:20px;"><li> Minimum 8 Maximum 12 Character Required.</li><li> Atleast One Uppercase Required.</li><li> Atleast One Lowercase Required.</li><li> Atleast One Numeric Required.</li><li> NO SPECIAL CHARACTERS ALLOWED.</li></ul>');
            }
            else {
                $("#TxtPasswordValidate").empty();
                TxtPasswordFlag = true;
            }
        }

        if (TxtEmailIdFlag == true && TxtPasswordFlag == true) {
            //SignIn();
            alert("Done");
        }
        else {
            alert("Invalid Inputs..!!")
        }
    });

});

function ClearText() {
    $("#TxtEmailId").val('');
    $("#TxtPassword").val('');
}

//function SignIn(){

//    var EmailId = $('#TxtEmailId').val(); 
//    var Password = $('#TxtPassword').val(); 

//    //AJAX
//     },
//     function(data, status){

//        if(data == 'Success'){

//            alert('Thank You For Your SignUp With Us!');
//        }
//        else{
//            alert(data);
//        }
//        ClearText();

//    });
//}
